﻿namespace comb;
public class Card
{
    public int CardPower { get; set; }

    public Suits CardSuit { get; set; }
    public Ranks CardRank { get; set; }
    public List<Card> Cards { get; private set; } = new List<Card>();
    public List<Card> TableCards { get; set; } = new List<Card>();
    public void InitializeCards()
    {
        foreach(Suits suit in Enum.GetValues(typeof(Suits)))
        {
            foreach (Ranks rank in Enum.GetValues(typeof(Ranks)))
            {
                Card card = new Card
                {
                    CardSuit = suit,
                    CardRank = rank,
                    CardPower = (int)rank + 2
                };
                Cards.Add(card);
            }
        }
    }

    public void AddCard(Player player)
    {
        for(int i  = 0; i < 2; i++)
        {
            Random random = new Random();
            int index = random.Next(0, Cards.Count);
            player.PlayerCards.Add(Cards[index]);
            Cards.RemoveAt(index);
        }
    }

   override public string ToString()
    {
        return $"{CardRank} of {CardSuit} power: {CardPower}";
    }
}
