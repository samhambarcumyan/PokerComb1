﻿using comb;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
Console.WriteLine("Hello, World!");


var Game = new Game();
Card card = new Card();
var tableCards = card.TableCards;
card.InitializeCards();
var p1 = new Player()
{
Name = "John Doe",
Points = 1500m,
PlayerCards = new List<Card>()
};
var p2 = new Player()
{
    Name = "Jason Statham",
    Points = 1500m,
    PlayerCards = new List<Card>()
};


p1.PlayerCards.Add(card.Cards[7]);
p1.PlayerCards.Add(card.Cards[7]);

foreach (var c in p1.PlayerCards)
{
    Console.WriteLine($"Player 1 Card: {c.ToString()}");
}

tableCards.Add(card.Cards[0]);
tableCards.Add(card.Cards[10]);
tableCards.Add(card.Cards[11]);
tableCards.Add(card.Cards[11]);
tableCards.Add(card.Cards[9]);





#region Combinations
//bool HasRoyalFlush(Player pl)
//{
//    var playerCardsConcatToTableCards =
//         pl.PlayerCards.Concat(tableCards)
//         .Where(card => card.CardRank >= Ranks.Ten)
//         .OrderByDescending(c => c.CardRank)
//         .ToList();
//    int RoyalFlushCount = 5;
//    return playerCardsConcatToTableCards.Count() == RoyalFlushCount && HasStraightFlush(pl);
//}
//bool HasStraightFlush(Player pl)
//    => HasStraight(pl) && HasFlush(pl);
//bool HasFlush(Player pl)
//{
//    var playerCardsConcatToTableCards =
//        pl.PlayerCards.Concat(tableCards)
//        .GroupBy(card => card.CardSuit)
//        .ToList();

//    bool FlushCount =
//         playerCardsConcatToTableCards.Count(c => c.Count() >= 5) == 1;

//    return FlushCount;
//}
//bool HasFullHouse(Player pl)// LINQ
//{

//    var group =
//        p1.PlayerCards.Concat(tableCards)
//        .GroupBy(c => c.CardRank)
//        .ToList();

//    bool hasSet =
//         group.Count(g => g.Count() == 3) == 1 &&
//        !group.Any(g => g.Count() > 3);

//    bool hasPair =
//         group.Count(g => g.Count() == 2) == 1;

//    return (hasSet && hasPair);
//}
//bool HasOnePair(Player pl) // Naming convention done
//{
//    int cardsPerPair = 2;
//    int requiredPairCount = 1;

//    bool hasPocketPair =
//        pl.PlayerCards[0].CardRank == pl.PlayerCards[1].CardRank;

//    var cardsGroupedByRank =
//        pl.PlayerCards
//        .Concat(tableCards)
//        .GroupBy(c => c.CardRank)
//        .ToList();

//    bool hasExactlyOnePair =
//        cardsGroupedByRank.Count(g => g.Count() == cardsPerPair) == requiredPairCount;

//    return hasPocketPair == true && !HasTwoPairs(pl);
//}
//bool HasStraight(Player pl)
//{
//    tableCards =
//    tableCards
//    .Concat(pl.PlayerCards)
//    .OrderByDescending(c => c.CardRank)
//    .DistinctBy(c => c.CardRank)
//    .ToList();

//    int StraightSuccesCounter = 5;
//    bool isStraight = false;
//    int iterationCounter = 0;

//    while(isStraight == false)
//    {
//        for(int i = 0; i <= tableCardsCount - 1; i++) // ++i and explain differances between ++i & i++ 
//        {
//            if (tableCards[iterationCounter].CardPower - tableCards[iterationCounter + 1].CardPower == 1)
//                iterationCounter++;

//            if(iterationCounter == StraightSuccesCounter) // avoid magic numbers
//                isStraight = true;
//        }
//        if (isStraight == false)
//            break;
//    }
//    return isStraight;
//}
//bool HasTwoPairs(Player pl)
//{

//    bool pocketPair =
//        pl.PlayerCards[0].CardRank == pl.PlayerCards[1].CardRank;

//         var groups = pl.PlayerCards
//        .Concat(tableCards)
//        .GroupBy(c => c.CardRank)
//        .ToList();

//    // avoid using magic numbers
//        bool hasTwoPairs =
//        pocketPair &&
//        groups.Count(g => g.Count() == 2) >= 2 &&
//        !groups.Any(g => g.Count() >= 3);

//    return hasTwoPairs;
//}
//bool HasSet(Player pl)
//{

//    bool pocketPair =
//        p1.PlayerCards[0].CardRank == p1.PlayerCards[1].CardRank;

//    var group = p1.PlayerCards
//        .Concat(tableCards)
//        .GroupBy(c => c.CardRank)
//        .ToList();

//    bool hasSet =
//        pocketPair &&
//        group.Count(g => g.Count() == 3) == 1 &&
//        !group.Any(g => g.Count() > 3);

//    return hasSet;

//}
//bool HasKaRe(Player pl)
//{
//    bool pocketPair =
//        pl.PlayerCards[0].CardRank == pl.PlayerCards[1].CardRank;

//    var group = pl.PlayerCards
//        .Concat(tableCards)
//        .GroupBy(c => c.CardRank)
//        .ToList();

//    bool hasKare =
//         pocketPair &&
//         group.Count(g => g.Count() == 4) == 1;

//    return hasKare;
//}

#endregion
//var tableCardsCount = tableCards.Count;

//Console.WriteLine();

//foreach(var c in tableCards)
//{
//    Console.WriteLine(c.ToString());
//}

//Console.WriteLine();

//CheckCombinations(p1);
//void CheckCombinations(Player pl)
//{
// can we avoid this if's
//    if (HasRoyalFlush(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Royal-Flush");
//        return;
//    }
//    if (HasStraightFlush(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Straight Flush");
//        return;
//    }
//    if (HasKaRe(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Four of Type");
//        return;
//    }
//    if (HasFullHouse(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Full House");
//        return;
//    }
//    if (HasFlush(pl))
//    {
//        Console.WriteLine($"{p1.Name} has combination Flush");
//        return;
//    }
//    if (HasStraight(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Straight");
//        return;
//    }
//    if (HasSet(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Three of Type");
//        return;
//    }
//    if (HasTwoPairs(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Two Pairs");
//        return;
//    }
//    if (HasOnePair(pl))
//    {
//        Console.WriteLine($"{pl.Name} has combination Two of Type");
//        return;
//    } 
//    else
//    {
//        Console.WriteLine($"{pl.Name} has combination High card");
//    }
//}