﻿using System;
using System.Collections.Generic;
using System.Text;

namespace comb;

public class Game : Combinations
{
    
}
