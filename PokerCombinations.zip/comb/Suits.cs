﻿using System;
using System.Collections.Generic;
using System.Text;

namespace comb
{
    public enum Suits
    {
        Hearts,
        Diamonds,
        Clubs,
        Spades
    }
}
